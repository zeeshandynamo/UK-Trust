package com.example.uktrust.Activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.uktrust.RetrofitFiles.ApiClient;
import com.example.uktrust.R;
import com.example.uktrust.RetrofitFiles.UserRequest;
import com.example.uktrust.RetrofitFiles.UserResponse;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Register extends AppCompatActivity {
    Button btn1;
    TextView tv1;
    EditText edname,edmobile,edemail,edpass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        edname = findViewById(R.id.etname);
        edmobile = findViewById(R.id.etphonee);
        edemail = findViewById(R.id.etemail);
        edpass = findViewById(R.id.etpass);


        btn1 = findViewById(R.id.reg_reg_btn);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String namee = edname.getText().toString().trim();
                String numberr = edmobile.getText().toString().trim();
                String emaill = edemail.getText().toString().trim();
                String passwordd = edpass.getText().toString().trim();


                if (TextUtils.isEmpty(namee)) {
                edname.setError("Enter Name");
            } else if (numberr.length() < 10) {
                edmobile.setError("Enter valid mobile number");
            } else if (numberr.length() > 10) {
                edmobile.setError("Enter valid mobile number");
            } else if (TextUtils.isEmpty(passwordd)) {
                edpass.setError("Password is required");
            } else if (TextUtils.isEmpty(emaill)) {
                edemail.setError("Email is required");
            } else if (Patterns.EMAIL_ADDRESS.matcher(emaill).matches()) {
                    saveUser(create_Request());
            } else {
                Toast.makeText(Register.this, "Invalid Email", Toast.LENGTH_LONG).show();
            }
            }
        });

        tv1 = findViewById(R.id.reg_login_tv);
        tv1.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(),Login.class)));
    }

    public UserRequest create_Request(){
        UserRequest userRequest = new UserRequest();
        userRequest.setName(edname.getText().toString());
        userRequest.setMobile(edmobile.getText().toString());
        userRequest.setEmail(edemail.getText().toString());
        userRequest.setPassword(edpass.getText().toString());

        return userRequest;
    }

    public void saveUser(UserRequest userRequest){
        Call<UserResponse> userResponseCall = ApiClient.getUserService().saveUsers(userRequest);
        userResponseCall.enqueue(new Callback<UserResponse>() {
            @Override
            public void onResponse(Call<UserResponse> call, Response<UserResponse> response) {

                UserResponse userResponse = response.body();
                String out = userResponse.getMessage();

                if (response.isSuccessful()){
                    if (out.equals("The given Mobile number already exists.") || out.equals("The given email already exists.")){
                        Toast.makeText(Register.this, userResponse.getMessage() , Toast.LENGTH_SHORT).show();
                    }else{
                        Toast.makeText(Register.this,userResponse.getMessage(), Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(),Home.class));
                        Toast.makeText(Register.this, "Saved succesfully", Toast.LENGTH_SHORT).show();
                    }
                }else {
                    Toast.makeText(Register.this, "Failed", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<UserResponse> call, Throwable t) {
                Toast.makeText(Register.this, "failed"+t.getLocalizedMessage(), Toast.LENGTH_SHORT).show();

            }
        });
    }
}