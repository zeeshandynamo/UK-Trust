package com.example.uktrust.Activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;

import com.example.uktrust.R;

public class Vetenary extends AppCompatActivity {
Button btnvetenary;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vetenary);
        Toolbar toolbar = findViewById(R.id.appbar);
        toolbar.setNavigationOnClickListener(v -> onBackPressed());
        btnvetenary = findViewById(R.id.btnvetenarycall);
        btnvetenary.setOnClickListener(v -> {
            Intent callingIntent = new Intent(Intent.ACTION_DIAL);
            callingIntent.setData(Uri.parse("tel:+91123546789"));
            startActivity(callingIntent);
        });
    }
}