package com.example.uktrust.Activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.example.uktrust.R;
import com.example.uktrust.RetrofitFiles.FetchuserResponse;
import com.example.uktrust.RetrofitFiles.User;
import com.example.uktrust.RetrofitFiles.UserService;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Profile extends AppCompatActivity {



TextView tv1,tv2;
String url="https://softcuts.in/api/v1/user_details/4/";
RecyclerView recyclerView;
List<User> userList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);


        tv1 = findViewById(R.id.tv1);
        tv1.setText("");
        tv2 = findViewById(R.id.tv2);
        tv2.setText("");

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(url)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        UserService api = retrofit.create(UserService.class);

        //Call<List<Post>> call = api.fetch_Users();


        Toolbar toolbar = findViewById(R.id.appbar);
        toolbar.setNavigationOnClickListener(v -> onBackPressed());

        //Bottom navigation start
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setSelectedItemId(R.id.profilemenu);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            switch (item.getItemId()){
                case R.id.sosmenu:
                    Intent callingIntent1 = new Intent(Intent.ACTION_DIAL);
                    callingIntent1.setData(Uri.parse("tel:+91123546789"));
                    startActivity(callingIntent1);
                    return true;

                case R.id.homemenu:
                    startActivity(new Intent(getApplicationContext(),Home.class));
                    overridePendingTransition(0,0);

                case R.id.profilemenu:
                    return true;
            }
            return false;
        });
        //Bottom navigation end



    }
}