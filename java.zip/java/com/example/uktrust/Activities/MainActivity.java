package com.example.uktrust.Activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import com.example.uktrust.R;

public class MainActivity extends AppCompatActivity {
Button btn1,btn2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn1= findViewById(R.id.main_login_btn);
        btn2= findViewById(R.id.main_reg_btn);

        btn1.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(),Login.class)));
        btn2.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(),Register.class)));
    }
}