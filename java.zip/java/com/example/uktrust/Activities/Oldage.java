package com.example.uktrust.Activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;

import com.example.uktrust.R;

public class Oldage extends AppCompatActivity {
Button btnoldage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oldage);
        Toolbar toolbar = findViewById(R.id.appbar);
        toolbar.setNavigationOnClickListener(v -> onBackPressed());

        btnoldage = findViewById(R.id.oldagecallbtn);
        btnoldage.setOnClickListener(v -> {
            Intent callingIntent = new Intent(Intent.ACTION_DIAL);
            callingIntent.setData(Uri.parse("tel:+91123546789"));
            startActivity(callingIntent);
        });
    }
}