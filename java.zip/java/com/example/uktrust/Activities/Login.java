package com.example.uktrust.Activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.uktrust.R;
import com.example.uktrust.RetrofitFiles.ApiClient;
import com.example.uktrust.RetrofitFiles.LoginResponse;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Login extends AppCompatActivity {
    Button btn1;
    TextView tv1;
    EditText edphone,edpass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        btn1 = findViewById(R.id.login_login_btn);
        tv1 = findViewById(R.id.login_reg_tv);

        edphone = findViewById(R.id.etemail);
        edpass = findViewById(R.id.etpass);

        //sharedPrefManager = new SharedPrefManager(getApplicationContext());

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = edphone.getText().toString().trim();
                String password = edpass.getText().toString().trim();

                if (TextUtils.isEmpty(password))
                {
                    edpass.setError("Password is required");
                    edpass.requestFocus();
                } else if (TextUtils.isEmpty(email))
                {
                    edphone.setError("Phone number is required");
                    edphone.requestFocus();
                } else
                {
                    //userLogin(create_Request());
                }
            }
        });

        tv1.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(),Home.class)));

    }


}