package com.example.uktrust.Activities;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageView;

import com.example.uktrust.R;
import com.example.uktrust.RetrofitFiles.SliderAdapter;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.smarteist.autoimageslider.IndicatorView.animation.type.IndicatorAnimationType;
import com.smarteist.autoimageslider.SliderAnimations;
import com.smarteist.autoimageslider.SliderView;

public class Home extends AppCompatActivity {
    ImageView ambulance,blood,herse,food,orphan,oldage,vetenary,doctor,
    horiblood,horiambulance,horiherse,horioldage,horidoctor;
    SliderView sliderView;
    int[] images = {R.drawable.ambulanceimg,
            R.drawable.bloodimg,
            R.drawable.herseimg,
            R.drawable.orphanimg,
            R.drawable.doctorimg,
            R.drawable.oldageimg};
    @SuppressLint("NonConstantResourceId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setSelectedItemId(R.id.homemenu);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            switch (item.getItemId()){
                case R.id.sosmenu:
                    Intent callingIntent = new Intent(Intent.ACTION_DIAL);
                    callingIntent.setData(Uri.parse("tel:+91123546789"));
                    startActivity(callingIntent);
                    return true;
                case R.id.homemenu:
                    return true;
                case R.id.profilemenu:
                    startActivity(new Intent(getApplicationContext(),Profile.class));
                    overridePendingTransition(5,5);
                    return true;
            }
            return false;
        });

        ambulance = findViewById(R.id.ambulancegif);
        blood = findViewById(R.id.bloodgif);
        herse = findViewById(R.id.hersegif);
        food = findViewById(R.id.foodgif);
        orphan = findViewById(R.id.orphangif);
        oldage = findViewById(R.id.oldagegif);
        doctor = findViewById(R.id.doctorgif);
        vetenary = findViewById(R.id.vetenarygif);

        //horizontalscrollview items

        horiblood = findViewById(R.id.horizontalblood);
        horiambulance = findViewById(R.id.horizontalambulance);
        horiherse = findViewById(R.id.horizontalherse);
        horioldage = findViewById(R.id.horizontalold);
        horidoctor = findViewById(R.id.horizontaldoctor);

        ambulance.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(),Ambulance.class)));

        blood.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(),Blood.class)));

        herse.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(),Herse.class)));

        food.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(),Food.class)));

        orphan.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(),Orphan.class)));

        oldage.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(),Oldage.class)));

        doctor.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(),Listofdoctors.class)));

        vetenary.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(),Vetenary.class)));

        //Horizontal scrollview on click listeners

        horiblood.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(),BloodDescription.class)));

        horiambulance.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(),AmbulanceDescription.class)));

        horiherse.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(),HerseDescription.class)));

        horioldage.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(),OldageDescription.class)));

        horidoctor.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(),DoctorDescription.class)));

        //slider view
        sliderView = findViewById(R.id.image_slider);
        SliderAdapter sliderAdapter = new SliderAdapter(images);

        sliderView.setSliderAdapter(sliderAdapter);
        sliderView.setIndicatorAnimation(IndicatorAnimationType.WORM);
        sliderView.setSliderTransformAnimation(SliderAnimations.DEPTHTRANSFORMATION);
        sliderView.startAutoCycle();



    }
}

//
