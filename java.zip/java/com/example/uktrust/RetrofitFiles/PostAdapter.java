package com.example.uktrust.RetrofitFiles;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.uktrust.R;

import java.util.ArrayList;
import java.util.List;

public class PostAdapter extends RecyclerView.Adapter<PostAdapter.PostViewHolder> {

    List<User> userList;
    Context context;

    public PostAdapter(Context context, List<User> userList){
        this.context= context;
        this.userList = new ArrayList<>();
    }


    @NonNull
    @Override
    public PostViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item,parent,false);
        return new PostViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull PostViewHolder holder, int position) {

        holder.id.setText(userList.get(position).getId());
        holder.name.setText(userList.get(position).getName());
        holder.mobile.setText(userList.get(position).getMobile());
        holder.email.setText(userList.get(position).getEmail());

    }

    @Override
    public int getItemCount() {
        return userList.size();
    }

    public class PostViewHolder extends RecyclerView.ViewHolder{

        TextView id,name,mobile,email;

        public PostViewHolder(@NonNull View itemView) {
            super(itemView);

            id = itemView.findViewById(R.id.rv_id);
            name = itemView.findViewById(R.id.rv_name);
            mobile = itemView.findViewById(R.id.rv_mob);
            email = itemView.findViewById(R.id.rv_email);

        }
    }
}
