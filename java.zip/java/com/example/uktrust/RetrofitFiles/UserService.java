package com.example.uktrust.RetrofitFiles;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface UserService {

    @Headers("Authorization: Basic YWRtaW46MTIzNA==")
    @POST("https://uk.graceinfotech.in/api/v1/user/")
    Call<UserResponse> saveUsers(@Body UserRequest userRequest);


}


